package com.localiza.aluguelcarros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalizaApplicationTests {

	@Test
	void contextLoads() {
	}

}
