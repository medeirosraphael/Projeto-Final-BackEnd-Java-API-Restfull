package com.localiza.aluguelcarros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalizaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalizaApplication.class, args);
	}

}
